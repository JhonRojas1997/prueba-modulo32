
import { getUsers } from "../../services/js/getData.js"
import { redirectIfLoggedIn } from "../../utils/routeGuard.js";
export default function registerView() {
    // para que espere hasta que recargue el dom
    setTimeout(() => {
        const registerButton = document.getElementById("registerButton")
        if (registerButton) {
            registerButton.addEventListener("click", async (e) => {
                // para prevenir que se recargue la pagina
                e.preventDefault();
                registerUser();
            })
        }
    }, 0);
    if (redirectIfLoggedIn()) return "";
    return `
    <div
      class="rounded row p-3 bg-light position-absolute top-50 start-50 translate-middle logPersonalizado"
    >
    <div class="mb-3 ">
       <h2 class="text-center mt-6">Register</h2>
      </div>
      <div class="mb-3">
        <label for="fullName" class="form-label">Fullname:</label>
        <input
          type="text"
          class="form-control"
          id="fullName"
          placeholder="Fullname"
        />
      </div>

      <div class="mb-3">
        <label for="username" class="form-label">Username:</label>
        <input
          type="text"
          class="form-control"
          id="username"
          placeholder="UserName"
        />
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">Email address:</label>
        <input
          type="email"
          class="form-control"
          id="email"
          placeholder="name@example.com"
        />
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Password:</label>
        <input
          type="password"
          class="form-control"
          id="password"
          placeholder="password"
        />
      </div>
      <div class="mb-3">
        <label for="conPassword" class="form-label">Confirm password:</label>
        <input
          type="password"
          class="form-control"
          id="conPassword"
          placeholder="Confirm password"
        />
      </div>

      <a href="#/login" data-link>Already have an account? Login</a>
      <button id="registerButton" class="btn logButtonPersonalized ">Register</button>
    </div>`
}

async function registerUser() {
    const username = document.getElementById("username").value.trim().toLowerCase();
    const fullName = document.getElementById("fullName").value.trim().toLowerCase();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value
    const conPassword = document.getElementById("conPassword").value
    const users = await getUsers()
    // se hace una verificacion de que coincida lo que encuentra en la bd con username o email 
    // con lo que ingresas en el input del html

    const exists = users.find(
        (user) => user.email === email || user.username === username
    )

    // verificaciones
    if( password !== conPassword) {
        alert("Passwords do not match") 
        return
    }
    if (!fullName || !username || !email || !password || !conPassword) {
        alert("Fill all fields")
    } else if (exists) {
        alert("User is already registered")
    } else {
        try {
            const res = await fetch("http://localhost:3000/users", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    fullName: fullName,
                    email: email,
                    username: username,
                    password: password,
                    userPicture: "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
                    role: "user"
                }),
            });
            // se crea un JSON que guarde al nuevo usuario
            const newUser = await res.json();
            const newUserData = { 
                "email": newUser.email,
                "username": newUser.username,
                "fullName": newUser.fullName,
                "role": newUser.role
            }
            // guardar en la sessionStorage la info de registro de usuario
            // si es exitoso se pone en true el auth
            sessionStorage.setItem("auth", "true")
            // guardar en user un objeto con los datos que contiene exists ((user) => user.email === email || user.username === username)
            // se agrega el newUser a la sessionStorage
            sessionStorage.setItem("user", JSON.stringify(newUserData))
        } catch (error) {
            console.log(error);
        }

        alert(`Bienvenid, ${fullName}`)
        // redireccional al home si el registro es exitoso
        location.hash = "/home";

    }
}






