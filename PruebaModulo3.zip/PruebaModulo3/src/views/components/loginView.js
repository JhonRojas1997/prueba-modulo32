
import { getUsers } from "../../services/js/getData.js"
import { redirectIfLoggedIn } from "../../utils/routeGuard.js";
export default function loginView() {
   setTimeout(() => {
        const loginButton = document.getElementById("loginButton")
        if (loginButton) {
            loginButton.addEventListener("click", async (e) => {
                // para prevenir que se recargue la pagina
                e.preventDefault();
                login();
            })
        }

    }, 0);
    if (redirectIfLoggedIn()) return "";
  return ` 
    <div
       class=" rounded row p-3 bg-light position-absolute top-50 start-50 translate-middle logPersonalizado" 
    >
    <div class="mb-3 ">
       <h2 class="text-center mt-6">Login</h2>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input
          type="email"
          class="form-control"
          id="email"
          placeholder="name@example.com"
        />
      </div>
      

      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input
          type="password"
          class="form-control"
          id="password"
          placeholder="password"
        />
      </div>
      
      <a href="#/register" data-link>Don't you have an account? Register</a>
      <button id = "loginButton" class="btn logButtonPersonalized">Login</button>
      
    </div>`;
}

async function login() {
  const email = document.getElementById("email").value.trim().toLowerCase();
  const password = document.getElementById("password").value;

  const users = await getUsers()
      // se hace una verificacion de que coincida lo que encuentra en la bd con username o email 
      // con lo que ingresas en el input del html
      const exists = users.find(
          (user) => user.email === email && user.password === password || user.username === email && user.password === password 
      )

    if(!email || !password){
      alert("fill all fields")
    }
    else if(exists){
      alert(`welcome ${exists.fullName}`)
      
       const registerData = {
                "email": exists.email,
                "username": exists.username,
                "fullName": exists.fullName,
                "role": exists.role
            }
            if(exists.role === "admin"){
              location.hash = "/admin";      
            }
            else{
              location.hash = "/home";
            }
        sessionStorage.setItem("auth", "true")
      sessionStorage.setItem("user", JSON.stringify(registerData))
      
    }
    else{
      alert("Wrong data, please enter the right data")
    }
}
