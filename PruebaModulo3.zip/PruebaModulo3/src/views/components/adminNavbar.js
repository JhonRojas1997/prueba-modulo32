export default function adminNavbar() {
    const user = JSON.parse(sessionStorage.getItem("user")) || { username: "Guest" };

    return `
    <aside class="columna-izquierda" id="columnaIzquierda">
        <div class="bajar">
          <button onclick="logout()" type="button" class="btn btn-danger w-100">
            Cerrar sesión
          </button>
        </div>
      </aside>
  `;
}