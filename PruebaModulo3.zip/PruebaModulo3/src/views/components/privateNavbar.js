export default function privateNavbar() {
  const user = JSON.parse(sessionStorage.getItem("user")) || { username: "Guest" };

  return `
  `;
}
