import privateNavbar from "./privateNavbar.js";
import { redirectIfNotLoggedIn } from "../../utils/routeGuard.js";
import {getCourses} from "../../services/js/getData.js"
export default function homeView() {
  setTimeout(() => {
    const userData = JSON.parse(sessionStorage.getItem("user"))
    const logoutBtn = document.getElementById("logoutBtn");
    const columnaIzquierda = document.getElementById("columnaIzquierda");
    
    if (columnaIzquierda) {
      columnaIzquierda.innerHTML = `
      <img
          class="perfil-img"
          src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png"
          alt=""
        />
        <h2>${userData.email}</h2>
        <h4 class = "email">${userData.email}</h4>
        <h3>Username: ${userData.username}</h3>
        <h3>Codigo postal: adsasdasdasdasd</h3>
        ` + columnaIzquierda.innerHTML;
  }
    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => {
        sessionStorage.clear();
        location.hash = "/login";
      });
    } 
  }, 0);
  courses()
if(!redirectIfNotLoggedIn()) return "";
  return `
    ${privateNavbar()}
    
    <section class="layout">
      <aside class="columna-izquierda" id="columnaIzquierda">
        <div class="bajar">
          <button
            type="button"
            class="actboton btn btn-warning d-block mx-auto mb-1"
            data-bs-toggle="modal"
            data-bs-target="#miModal3"
          >
            Actualizar datos
          </button>
          <button onclick="logout()" class="btn btn-danger w-100">
            Cerrar sesión
          </button>
        </div>
      </aside>
      <main class="columna-derecha">
        <section class="container py-5">
            <div class="row g-4" id="courses-container"></div>
        </section>
    
  `;
}

async function courses() {
    const courses = await getCourses();
    const coursesContainer = document.getElementById("courses-container");
    const userData = JSON.parse(sessionStorage.getItem("user"));
    
    const email = userData.email;
    coursesContainer.innerHTML = "";
    courses.forEach(course => {
      let registerOrNot = "";
    
    if (course.assistants.includes(email)) {
      registerOrNot = "Yes";
    }
    if (!course.assistants.includes(email)) {
      registerOrNot = "Not";
    }
        coursesContainer.innerHTML += `
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="ratio ratio-1x1">
                        <img src="${course.image}" class="card-img-top object-fit-cover" alt="courseImg">
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div>
                            <h5 class="card-title">${course.title}</h5>
                            <p class="card-text">${course.description}</p>
                            <p class="card-text"><small class="text-body-secondary">Registered: ${registerOrNot}</small></p>
                            <p class="card-text"><small class="text-body-secondary">Capacity: ${course.assistants.length} / ${course.afforum}</small></p>
                            <p class="card-text"><small class="text-body-secondary">Published: ${course.date}</small></p>
                            <button class="btn btn-danger mt-2" onclick="asistCourse('${course.id}', ${course.afforum})">Asistir</button>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
}

async function asistCourse(id, afforum){
  const courses = await getCourses();
   const confirmAsist = confirm(
    "¿Are you sure want to asist this course?"
  );
  if (!confirmAsist) {
    alert("Operation cancelled.");
    return;
  }
  
  try {
    const resCourse = await fetch(`http://localhost:3000/courses/${id}`);
    const course = await resCourse.json();
    const userData = JSON.parse(sessionStorage.getItem("user"));
    
    const email = userData.email;
    const registerAssistants = course.assistants || [];
    
     if (registerAssistants.includes(email)) {
      alert("The user is already registered in this event");
      return;
    }
    if (registerAssistants.length >= course.afforum) {
  alert("No hay más cupos disponibles");
  return;
}

    
    const updAssistants = [...registerAssistants, email];
    const res = await fetch(`http://localhost:3000/courses/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
        assistants: updAssistants
      })
    });
    

    if (res.ok) {
      alert("Se ha suscrito al curso");
    } else {
      alert("No se ha suscrito al curso");
    }
  } catch (error) {
    console.error(error);
  }

}


window.asistCourse = asistCourse;

