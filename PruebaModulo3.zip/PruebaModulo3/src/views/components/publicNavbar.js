export default function publicNavbar() {
  return `
    
  `;
}
