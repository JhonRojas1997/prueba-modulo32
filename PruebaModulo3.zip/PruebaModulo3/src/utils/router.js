    import { isAuthenticated } from "./routeGuard.js";
    const routes = {
        "/": async () => await import("../views/components/loginView.js"),
        "/register": async () => await import("../views/components/registerView.js"),
        "/login": async () => await import("../views/components/loginView.js"),
        "/home": async () => await import("../views/components/homeView.js"),
        "/admin": async () => await import("../views/components/adminView.js"),
    }



    export async function router() {
    const hash = location.hash.slice(1).toLowerCase() || "/";

    // Bloquear acceso directo a /home si no hay sesión
    if (hash === "home" && !isAuthenticated()) {
        location.hash = "/login";
        return;
    }

    const viewFunc = routes[hash] || routes["/login"];
    const view = await viewFunc();
    document.getElementById("content").innerHTML = view.default();
    }
