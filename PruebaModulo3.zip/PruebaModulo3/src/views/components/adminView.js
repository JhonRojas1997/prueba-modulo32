import adminNavbar from "./adminNavbar.js";
import { protectAdminRoute } from "../../utils/routeGuard.js";
import { getCourses } from "../../services/js/getData.js";

export default function adminView() {
  // botón para salir de la sesión
  setTimeout(() => {
        const logoutBtn = document.getElementById("logoutBtn");
        const addButton = document.getElementById("addButton")
        const updateButton = document.getElementById("updateButton")
        if (logoutBtn) {
            logoutBtn.addEventListener("click", () => {
                sessionStorage.clear();
                location.hash = "/login";
            });
        }
        if (addButton) {
            addButton.addEventListener("click", () => {
                addCourse();
            });
        }
        if (updateButton) {
      updateButton.addEventListener("click", () => {
        updateCourse();
      });
    }
    }, 0);

  courses();
  if (!protectAdminRoute()) return "";
  return `
        ${adminNavbar()}
    
        <section class="container py-5" >
                <div class="row g-4" id="courses-container"></div>

        </section>
        <button type="button" class="btn btn-primary position-fixed bottom-0 m-3 " data-bs-toggle="modal" data-bs-target="#courseModal">
        Add course
        </button>

        <div
          class="modal fade"
          id="courseModal"
          tabindex="-1"
          aria-labelledby="courseModalLabel"
          aria-hidden="true"
        >
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">
              <div class="modal-header">
                <h5 class="modal-title" id="courseModalLabel">Create course</h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Cerrar"
                ></button>
              </div>
              <div class="modal-body">
                <form id="newCourseForm">
                  <div class="mb-3">
                    <label for="courseTitle" class="form-label text-black"
                      >Title</label
                    >
                    <input
                      type="text"
                      class="form-control"
                      id="courseTitle"
                      required
                    />
                  </div>
                  <div class="mb-3">
                    <label for="courseImage" class="form-label text-black"
                      >Image URL</label
                    >
                    <input
                      type="text"
                      class="form-control"
                      id="courseImage"
                      required
                    />
                  </div>

                  <div class="mb-3">
                    <label for="courseAfforum" class="form-label text-black"
                      >Capacity:</label
                    >
                    <input
                      type="number"
                      class="form-control"
                      id="courseAfforum"
                      required
                    />
                  </div>

                  <div class="mb-3">
                    <label
                      for="courseDescription"
                      class="form-label text-black"
                      >Description</label
                    >
                    <textarea
                      class="form-control"
                      id="courseDescription"
                      rows="3"
                      required
                    ></textarea>
                  </div>
                  <div class="d-flex justify-content-between">
                    <button
                      id="addButton"
                      type="button"
                      class="btn btn-primary"
                    >
                      Addddd
                    </button>
                    <button
                      type="button"
                      class="btn btn-secondary"
                      data-bs-dismiss="modal"
                    >
                      Cerrar
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- Modal Actualizar Curso -->
<div class="modal fade" id="miModal2" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Actualizar curso</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="update-id">

        <div class="mb-3">
          <label class="form-label">Title: </label>
          <input type="text" class="form-control" id="update-title">
        </div>
        <div class="mb-3">
          <label class="form-label">Afforum </label>
          <input type="number" class="form-control" id="update-afforum">
        </div>

        <div class="mb-3">
          <label class="form-label">Descripción: </label>
          <textarea class="form-control" id="update-description" rows="3"></textarea>
        </div>

        
      </div>
      <div class="modal-footer">
        <button id="updateButton" class="btn btn-primary">Actualizar</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>

     `;
}

async function addCourse() {
  const courseTitle = document.getElementById("courseTitle").value;
  const courseImage = document.getElementById("courseImage").value;
  const courseDescription = document.getElementById("courseDescription").value;
  const courseAfforum = document.getElementById("courseAfforum").value
  let date = new Date().toLocaleString("es-CO");
  const courses = await getCourses();

  // some busca y devuelve true (si existe) o false si no
  const exists = courses.some((course) => course.name === courseTitle);

  if (!courseTitle || !courseImage || !courseDescription) {
    alert("Fill all fields");
  } else if (exists) {
    alert("This course is already in our database");
  } else {
    try {
      const res = await fetch("http://localhost:3000/courses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: courseTitle,
          image: courseImage,
          description: courseDescription,
          date: date,
          afforum: courseAfforum,
          assistants: []
        }),
      });
      alert("Course created successfully");
    } catch (error) {
      console.log(error);
    }
  }
}

async function courses() {
    const courses = await getCourses();
    const coursesContainer = document.getElementById("courses-container")
    courses.forEach(course => {
        console.log(course)
        coursesContainer.innerHTML +=
            `
            <div class="col-md-4">
                <div class="card h-100" >
                    <div class="ratio ratio-1x1">
                        <img src="${course.image}" class="card-img-top h-10 w-18rem" alt="courseImg">
                    </div>
                        <div class="card-body">
                        <h5 class="card-title">${course.title}</h5>
                        <p class="card-text">${course.description}</p>
                        <p class="card-text"><small class="text-body-secondary">Capacity: ${course.assistants.length} / ${course.afforum}</small></p>
                        <p class="card-text"><small class="text-body-secondary">Published: ${course.date}</small></p>
                    <button class="btn btn-danger mt-2" onclick="deleteCourse('${course.id}')">Eliminar</button>
            <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#miModal2" onclick="loadCourse('${course.id}')">Actualizar</button>
                </div>
                     
            </div>
        
        `
    });

}



async function deleteCourse(id) {
  const confirmDelete = confirm(
    "¿Are you sure want to delete this course?"
  );
  if (!confirmDelete) {
    alert("Operation cancelled.");
    return;
  }
  try {
    const res = await fetch(`http://localhost:3000/courses/${id}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    if (res.ok) {
      alert("Curso eliminado Correctamente");
    } else {
      alert("Error al eliminar el curso");
    }
  } catch (error) {
    console.error("Error de red:", error);
  }
}
window.deleteCourse = deleteCourse;

async function loadCourse(id) {
  const res = await fetch(`http://localhost:3000/courses/${id}`);
  const data = await res.json();

  document.getElementById("update-id").value = data.id;
  document.getElementById("update-title").value = data.title;
  document.getElementById("update-afforum").value = data.afforum;
  document.getElementById("update-description").value = data.description;
}

window.loadCourse = loadCourse;

async function updateCourse() {
  const id = document.getElementById("update-id").value;
  const title = document.getElementById("update-title").value;
  const afforum = document.getElementById("update-afforum").value;
  const description = document.getElementById("update-description").value;

  const res = await fetch(`http://localhost:3000/courses/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, afforum, description }),
  });

  if (res.ok) {
    alert("Course updated successfully");
  } else {
    alert("Error updating course");
  }
}